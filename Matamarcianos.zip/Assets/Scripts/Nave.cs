using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
using UnityEngine.SceneManagement;

public class Nave : MonoBehaviour
{
    [SerializeField] private float velocidad = 10f; // unidades de pantalla por segundo
    [SerializeField] Transform prefabDisparo;
    [SerializeField] private float velocidadDisparo = 5f;
    private float xInicial;
    private float yInicial;
    private float xBordeIzquierdo;
    private float xBordeDerecho;

    // Start is called before the first frame update
    void Start()
    {
        xInicial = transform.position.x;
        yInicial = transform.position.y;
        xBordeIzquierdo = -4.5f;
        xBordeDerecho = 4.5f;
    }

    // Update is called once per frame
    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");

        if (transform.position.x < xBordeIzquierdo || 
            transform.position.x > xBordeDerecho)
            SepararDelBorde();
        else
            transform.Translate(horizontal * velocidad * Time.deltaTime, 0, 0);

        if (Input.GetButtonDown("Fire1"))
        {
            Disparar();
        }

        if (Input.GetKey(KeyCode.Escape))
            SceneManager.LoadScene("Menu");        
    }

    private void Disparar()
    {
        ReproducirSonido();

        Transform disparo =  Instantiate(prefabDisparo, transform.position, 
            Quaternion.identity);
        disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
            new Vector3(0, velocidadDisparo, 0);        
    }

    private void ReproducirSonido()
    {
        GetComponent<AudioSource>().Play();
       
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "DisparoEnemigo" || other.tag == "Enemigo" ||
            other.tag == "EnemigoMarciano")
        {
            FindObjectOfType<GameController>().SendMessage("PerderVida");
            Recolocar();
            RecolocarEnemigos();
        }
    }

    private void Recolocar()
    {        
        transform.position = new Vector3(xInicial, yInicial, 0);
    }

    private void RecolocarEnemigos()
    {
        foreach (Enemigo enemigo in FindObjectsOfType<Enemigo>())
            enemigo.SendMessage("Recolocar");
        foreach (Enemigo2Marciano marciano in 
            FindObjectsOfType<Enemigo2Marciano>())
            marciano.SendMessage("Recolocar");
    }

    private void SepararDelBorde()
    {
        float xSeparada = 4.5f;

        if (transform.position.x < -4.5)
            transform.position = new Vector3(-xSeparada, transform.position.y, 0);
        else
            transform.position = new Vector3(xSeparada, transform.position.y, 0);
    }
}
