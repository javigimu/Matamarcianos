using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nave : MonoBehaviour
{
    [SerializeField] private float velocidad = 10f; // unidades de pantalla por segundo
    [SerializeField] Transform prefabDisparo;
    [SerializeField] private float velocidadDisparo = 5f;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        transform.Translate(horizontal * velocidad * Time.deltaTime, 0, 0);

        if (Input.GetButtonDown("Fire1"))
            Disparar();
        
    }

    private void Disparar()
    {
        ReproducirSonido();

        Transform disparo =  Instantiate(prefabDisparo, transform.position, 
            Quaternion.identity);
        disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
            new Vector3(0, velocidadDisparo, 0);        
    }

    private void ReproducirSonido()
    {
        GetComponent<AudioSource>().Play();
       
    }
}
