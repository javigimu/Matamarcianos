using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public static int puntos = 0;
    public static byte vidas = 3;
    [SerializeField] TextMeshProUGUI textoMarcador;    
    private static int nivel = 1;
    [SerializeField] int nivelActual;
    private int nivelMaximo = 2;
    private int cantidadEnemigos;
    private int cantidadMarcianos;

    // Start is called before the first frame update
    void Start()
    {
        nivel = nivelActual;
        ActualizarMarcador();
        cantidadEnemigos = FindObjectsOfType<Enemigo>().Length;
        cantidadMarcianos = FindObjectsOfType<Enemigo2Marciano>().Length;
    }
    
    // Update is called once per frame
    void Update()
    {
        
    }

    private void ActualizarMarcador()
    {
        textoMarcador.text = "Puntos: " + puntos + Environment.NewLine +
            "Vidas: " + vidas;
    }

    private void SubirNivel()
    {        
        nivel++;
        if (nivel <= nivelMaximo)
        {
            SceneManager.LoadScene("Nivel" + nivel);
        }
        else if (nivel > nivelMaximo)
        {
            MostrarMenu();           
        }
    }

    private void MostrarMenu()
    {
        ActualizarMarcador();
        SceneManager.LoadScene("Menu"); 
    }

    public void ResetearPuntosYVidas()
    {
        nivel = 0;
        puntos = 0;
        vidas = 3;
    }

    private void PerderVida()
    {
        if (vidas > 0)
        {
            vidas--;
            RecolocarEnemigos();
            ActualizarMarcador();
        }

        if (vidas <= 0)
        {
            MostrarMenu();
        }
    }

    private void DestruirEnemigo(string enemigo)
    {
        switch(enemigo)
        {
            case "Enemigo": 
                puntos += 10;
                cantidadEnemigos--;
                break;
            case "EnemigoMarciano": 
                puntos += 20;
                cantidadMarcianos--;
                break;
        }

        ActualizarMarcador();      
        if (cantidadEnemigos <= 0 && cantidadMarcianos <= 0)
        {
            SubirNivel();
        }
    }

    private void RecolocarEnemigos()
    {
        foreach (Enemigo enemigo in FindObjectsOfType<Enemigo>())
        {
            enemigo.SendMessage("Recolocar");
        }
    }
}
