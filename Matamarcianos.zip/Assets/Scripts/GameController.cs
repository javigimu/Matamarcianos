using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public static int puntos = 0;
    public static byte vidas = 3;
    [SerializeField] TextMeshProUGUI textoMarcador;
    private static int nivel = 1;
    private int nivelMaximo = 2;
    private int cantidadEnemigos;
    private int cantidadMarcianos;

    // Start is called before the first frame update
    void Start()
    {
        ActualizarMarcador();
        cantidadEnemigos = FindObjectsOfType<Enemigo>().Length;
        cantidadMarcianos = FindObjectsOfType<Enemigo2Marciano>().Length;
    }
    
    // Update is called once per frame
    void Update()
    {
        
    }

    private void ActualizarMarcador()
    {
        textoMarcador.text = "Puntos: " + puntos + Environment.NewLine +
            "Vidas: " + vidas;
    }

    private void SubirNivel()
    {        
        nivel++;
        if (nivel <= nivelMaximo)
        {
            SceneManager.LoadScene("Nivel" + nivel);
        }
        else if (nivel > nivelMaximo)
        {
            MostrarMenu();           
        }
    }

    private void MostrarMenu()
    {
        nivel = 1;
        puntos = 0;
        vidas = 3;
        SceneManager.LoadScene("Menu");
    }

    private void PerderVida()
    {
        if (vidas > 0)
        {
            vidas--;
            RecolocarEnemigos();
            ActualizarMarcador();
        }

        if (vidas <= 0)
        {
            MostrarMenu();
        }
    }

    private void DestruirEnemigo(int puntosEnemigo)
    {
        puntos += puntosEnemigo;
        ActualizarMarcador();      
        
        cantidadEnemigos = FindObjectsOfType<Enemigo>().Length;
        cantidadMarcianos = FindObjectsOfType<Enemigo2Marciano>().Length;
 
        if (cantidadEnemigos <= 1 && cantidadMarcianos <= 1)
        {
            SubirNivel();
        }
    }

    private void RecolocarEnemigos()
    {
        foreach (Enemigo enemigo in FindObjectsOfType<Enemigo>())
        {
            enemigo.SendMessage("Recolocar");
        }
    }
}
