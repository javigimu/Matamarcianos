using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemigo : MonoBehaviour
{
    [SerializeField] Transform prefabDisparoEnemigo;
    private float velocidadDisparo = -5f;
    private float velocidadX = 4f;
    private float velocidadY = -1f;

    // Start is called before the first frame update
    void Start()
    {
        if (transform.position.x > 3)
            velocidadX = -velocidadX;
        StartCoroutine(Disparar());
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(velocidadX * Time.deltaTime,
            velocidadY * Time.deltaTime, 0);

        if ((transform.position.x < -4) || (transform.position.x > 4))
        {
            velocidadX = -velocidadX;
            ReproducirSonidoCambioDireccion();
        }
        if ((transform.position.y < -2.5) || (transform.position.y > 2.5))
        {
            velocidadY = -velocidadY;
            ReproducirSonidoCambioDireccion();
        }
    }

    private void ReproducirSonidoCambioDireccion()
    {
        GetComponent<AudioSource>().Play();
    }

    private IEnumerator Disparar()
    {
        float pausa = Random.Range(3.0f, 8.0f);
        yield return new WaitForSeconds(pausa);

        Transform disparo = Instantiate(prefabDisparoEnemigo,
            transform.position, Quaternion.identity);

        disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
            new Vector3(0, velocidadDisparo, 0);

        StartCoroutine(Disparar());
    }
}
