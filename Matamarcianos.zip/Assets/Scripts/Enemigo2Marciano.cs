using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemigo2Marciano : MonoBehaviour
{
    private float xInicial;
    private float yInicial;
    private float velocidadX = 1f;
    private float velocidadX1 = -2f;
    private float velocidadX2 = 2f;
    private float velocidadY = -3f;

    // Start is called before the first frame update
    void Start()
    {
        xInicial = transform.position.x;
        yInicial = transform.position.y;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(velocidadX * Time.deltaTime,
            velocidadY * Time.deltaTime, 0);

        if (transform.position.x < velocidadX1 ||
            transform.position.x > velocidadX2)
            velocidadX = -velocidadX;

        if (transform.position.y < -2.5 || transform.position.y > 2.5)
            velocidadY = -velocidadY;
    }

    private void Recolocar()
    {
        transform.position = new Vector3(xInicial, yInicial, 0);
    }
}
