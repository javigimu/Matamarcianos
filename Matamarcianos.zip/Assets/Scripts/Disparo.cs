using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Disparo : MonoBehaviour
{
    [SerializeField] Transform prefabExplosion;
    [SerializeField] Transform prefabExplosionMarciano;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        /*if (transform.position.y > 5)
        {
            Destroy(gameObject);
        }*/
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        int puntosObtenidos = 0;
        if (other.tag == "Enemigo" ||other.tag == "EnemigoMarciano")
        {
            Transform explosion = null;
            if (other.tag == "Enemigo")
            {
                explosion = Instantiate(prefabExplosion,
                    other.transform.position, Quaternion.identity);
                puntosObtenidos = 10;               
            }
            else if (other.tag == "EnemigoMarciano")
            {
                explosion = Instantiate(prefabExplosionMarciano,
                    other.transform.position, Quaternion.identity);
                puntosObtenidos = 20;
            }

            Destroy(other.gameObject);
            Destroy(explosion.gameObject, 1f);
            Destroy(gameObject);
            FindObjectOfType<GameController>()
                   .SendMessage("DestruirEnemigo", puntosObtenidos);
        }
        else if (other.tag == "TopeSuperior")
            Destroy(gameObject);
    }
}
