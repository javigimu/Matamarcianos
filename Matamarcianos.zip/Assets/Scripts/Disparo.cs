using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Disparo : MonoBehaviour
{
    [SerializeField] Transform prefabExplosion;
    [SerializeField] Transform prefabExplosionMarciano;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        /*if (transform.position.y > 5)
        {
            Destroy(gameObject);
        }*/
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Enemigo" ||other.tag == "EnemigoMarciano")
        {
            Transform explosion = null;
            if (other.tag == "Enemigo")
            {
                explosion = Instantiate(prefabExplosion,
                    other.transform.position, Quaternion.identity);
                FindObjectOfType<GameController>()
                   .SendMessage("DestruirEnemigo", "Enemigo");
            }
            else if (other.tag == "EnemigoMarciano")
            {
                explosion = Instantiate(prefabExplosionMarciano,
                    other.transform.position, Quaternion.identity);
                FindObjectOfType<GameController>()
                   .SendMessage("DestruirEnemigo", "EnemigoMarciano");
            }
            Destroy(other.gameObject);
            Destroy(explosion.gameObject, 1f);
            Destroy(gameObject);            
        }
        else if (other.tag == "TopeSuperior")
            Destroy(gameObject);
    }
}
